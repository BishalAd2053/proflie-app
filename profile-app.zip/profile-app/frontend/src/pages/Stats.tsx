import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';

interface Contribution {
  id: number;
  date: string;
  count: number;
}

const getYear = (dateStr: string) => new Date(dateStr).getFullYear();

const fetchContributions = async (year: number): Promise<Contribution[]> => {
  const res = await fetch(`/api/stats/contributions?year=${year}`);
  if (!res.ok) {
    throw new Error('Failed to fetch contributions');
  }
  return res.json();
};

/**
 * Stats page fetches contribution data for the selected year and renders a simple
 * heatmap representation. For brevity this uses a basic CSS grid; you can
 * replace it with Recharts or any other charting library.
 */
function Stats() {
  const currentYear = new Date().getFullYear();
  const [year, setYear] = useState(currentYear);
  const { data: contributions, isLoading, error } = useQuery(
    ['contributions', year],
    () => fetchContributions(year),
  );

  const handleYearChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setYear(Number(e.target.value));
  };

  if (isLoading) return <div className="p-4">Loading…</div>;
  if (error) return <div className="p-4 text-red-600">Error loading stats</div>;

  return (
    <div className="p-4 container mx-auto">
      <div className="mb-4">
        <label htmlFor="year" className="mr-2 font-semibold">Year:</label>
        <select id="year" value={year} onChange={handleYearChange} className="border rounded p-1">
          {[currentYear, currentYear - 1, currentYear - 2].map((y) => (
            <option key={y} value={y}>{y}</option>
          ))}
        </select>
      </div>
      <div className="grid grid-cols-53 gap-1">
        {contributions?.map((c) => {
          // Color intensity based on count
          const intensity = Math.min(c.count / 4, 1);
          const bgColor = `rgba(34,197,94,${intensity})`;
          return (
            <div key={c.id} title={`${c.date}: ${c.count} contributions`} className="w-3 h-3" style={{ backgroundColor: bgColor }} />
          );
        })}
      </div>
    </div>
  );
}

export default Stats;