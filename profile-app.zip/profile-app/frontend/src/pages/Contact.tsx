import { useForm } from 'react-hook-form';
import { z } from 'zod';

// Define a schema for validation using Zod
const schema = z.object({
  name: z.string().min(1, { message: 'Name is required' }),
  email: z.string().email({ message: 'Invalid email address' }),
  body: z.string().min(1, { message: 'Message is required' }),
});

type FormData = z.infer<typeof schema>;

/**
 * Contact page provides a form for sending messages to the backend. Uses
 * react-hook-form for state management and Zod for schema validation.
 */
function Contact() {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>({
    resolver: async (values) => {
      try {
        const parsed = schema.parse(values);
        return { values: parsed, errors: {} };
      } catch (err: any) {
        return { values: {}, errors: err.formErrors.fieldErrors };
      }
    },
  });

  const onSubmit = async (data: FormData) => {
    const response = await fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (response.ok) {
      alert('Message sent successfully');
      reset();
    } else {
      alert('Failed to send message');
    }
  };

  return (
    <div className="container mx-auto p-4 max-w-md">
      <h2 className="text-2xl font-semibold mb-4">Contact Me</h2>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label className="block mb-1">Name</label>
          <input
            {...register('name')}
            className="w-full border rounded p-2"
          />
          {errors.name && <p className="text-sm text-red-600">{errors.name?.message as string}</p>}
        </div>
        <div>
          <label className="block mb-1">Email</label>
          <input
            {...register('email')}
            type="email"
            className="w-full border rounded p-2"
          />
          {errors.email && <p className="text-sm text-red-600">{errors.email?.message as string}</p>}
        </div>
        <div>
          <label className="block mb-1">Message</label>
          <textarea
            {...register('body')}
            rows={4}
            className="w-full border rounded p-2"
          ></textarea>
          {errors.body && <p className="text-sm text-red-600">{errors.body?.message as string}</p>}
        </div>
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
          Send
        </button>
      </form>
    </div>
  );
}

export default Contact;