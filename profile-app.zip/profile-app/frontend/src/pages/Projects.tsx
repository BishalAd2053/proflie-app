import { useQuery } from '@tanstack/react-query';

interface Project {
  id: number;
  name: string;
  description: string;
  url: string;
  repo: string;
  tags: string[];
  featured: boolean;
}

const fetchProjects = async (): Promise<Project[]> => {
  const res = await fetch('/api/projects');
  if (!res.ok) {
    throw new Error('Failed to fetch projects');
  }
  return res.json();
};

/**
 * Projects page fetches the list of projects from the backend and displays
 * each as a card with name, description, tags and links to the demo and repo.
 */
function Projects() {
  const { data: projects, isLoading, error } = useQuery(['projects'], fetchProjects);
  if (isLoading) return <div className="p-4">Loading…</div>;
  if (error) return <div className="p-4 text-red-600">Error loading projects</div>;
  return (
    <div className="container mx-auto p-4 grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
      {projects?.map((project) => (
        <div key={project.id} className="border rounded-lg p-4 shadow-sm hover:shadow-md transition-all">
          <h2 className="text-xl font-semibold mb-2 flex items-center">
            {project.name}
            {project.featured && (
              <span className="ml-2 text-xs bg-green-200 text-green-800 px-2 py-1 rounded-full">
                Featured
              </span>
            )}
          </h2>
          <p className="mb-3 text-sm text-gray-600 dark:text-gray-300">
            {project.description}
          </p>
          <div className="flex flex-wrap gap-2 mb-3">
            {project.tags.map((tag) => (
              <span key={tag} className="text-xs bg-gray-200 dark:bg-gray-700 px-2 py-1 rounded">
                {tag}
              </span>
            ))}
          </div>
          <div className="flex gap-4 text-sm">
            <a href={project.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
              Live
            </a>
            <a href={project.repo} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
              Repo
            </a>
          </div>
        </div>
      ))}
    </div>
  );
}

export default Projects;