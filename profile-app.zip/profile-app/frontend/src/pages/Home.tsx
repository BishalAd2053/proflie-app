import { motion } from 'framer-motion';

/**
 * Landing page showcasing a hero section. Uses Framer Motion for simple
 * entrance animation. Update the content to reflect your own profile.
 */
function Home() {
  return (
    <div className="container mx-auto p-8">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-4xl font-bold mb-4"
      >
        Welcome to My Profile
      </motion.h1>
      <p className="text-lg mb-6">
        I'm a software developer passionate about building high quality web
        applications. Explore my projects, experience timeline, contribution
        stats and contact me below.
      </p>
    </div>
  );
}

export default Home;