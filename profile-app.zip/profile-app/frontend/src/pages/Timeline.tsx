import { useQuery } from '@tanstack/react-query';

interface Experience {
  id: number;
  orgName: string;
  role: string;
  startDate: string;
  endDate: string | null;
  summary: string;
  bullets: string[];
}

const fetchTimeline = async (): Promise<Experience[]> => {
  const res = await fetch('/api/timeline');
  if (!res.ok) {
    throw new Error('Failed to fetch timeline');
  }
  return res.json();
};

/**
 * Timeline page displays chronological experiences fetched from the backend.
 */
function Timeline() {
  const { data: items, isLoading, error } = useQuery(['timeline'], fetchTimeline);
  if (isLoading) return <div className="p-4">Loading…</div>;
  if (error) return <div className="p-4 text-red-600">Error loading timeline</div>;
  return (
    <div className="container mx-auto p-4 space-y-6">
      {items?.map((item) => (
        <div key={item.id} className="border-l-4 border-blue-500 pl-4 relative">
          <div className="absolute -left-2 top-0 w-4 h-4 bg-blue-500 rounded-full"></div>
          <h3 className="text-lg font-semibold">
            {item.role} @ {item.orgName}
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
            {item.startDate} – {item.endDate ?? 'Present'}
          </p>
          <p className="mb-2 text-sm">{item.summary}</p>
          <ul className="list-disc ml-6 text-sm space-y-1">
            {item.bullets.map((b, i) => (
              <li key={i}>{b}</li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}

export default Timeline;