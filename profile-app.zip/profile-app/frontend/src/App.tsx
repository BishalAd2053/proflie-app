import { Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Projects from './pages/Projects';
import Timeline from './pages/Timeline';
import Stats from './pages/Stats';
import Contact from './pages/Contact';

/**
 * Main application component defining routes and simple navigation.
 */
function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <nav className="bg-gray-100 dark:bg-gray-800 p-4 shadow-md">
        <ul className="flex gap-4 justify-center">
          <li><Link to="/" className="hover:underline">Home</Link></li>
          <li><Link to="/projects" className="hover:underline">Projects</Link></li>
          <li><Link to="/timeline" className="hover:underline">Timeline</Link></li>
          <li><Link to="/stats" className="hover:underline">Stats</Link></li>
          <li><Link to="/contact" className="hover:underline">Contact</Link></li>
        </ul>
      </nav>
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/timeline" element={<Timeline />} />
          <Route path="/stats" element={<Stats />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;