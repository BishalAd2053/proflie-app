package com.example.profile.repo;

import com.example.profile.model.Experience;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository for Experience entities.
 */
public interface ExperienceRepository extends JpaRepository<Experience, Long> {
}