package com.example.profile.repo;

import com.example.profile.model.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository for UserProfile entities.
 */
public interface UserProfileRepository extends JpaRepository<UserProfile, Long> {
}