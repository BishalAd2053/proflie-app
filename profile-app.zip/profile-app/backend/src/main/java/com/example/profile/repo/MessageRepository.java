package com.example.profile.repo;

import com.example.profile.model.Message;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository for Message entities.
 */
public interface MessageRepository extends JpaRepository<Message, Long> {
}