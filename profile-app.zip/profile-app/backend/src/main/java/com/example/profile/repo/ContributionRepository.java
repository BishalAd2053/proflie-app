package com.example.profile.repo;

import com.example.profile.model.Contribution;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

/**
 * Repository for Contribution entities.
 */
public interface ContributionRepository extends JpaRepository<Contribution, Long> {
    List<Contribution> findAllByDateBetween(LocalDate start, LocalDate end);
}