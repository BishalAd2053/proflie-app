package com.example.profile.repo;

import com.example.profile.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository for Project entities.
 */
public interface ProjectRepository extends JpaRepository<Project, Long> {
}