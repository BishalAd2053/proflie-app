package com.example.profile;

import com.example.profile.model.*;
import com.example.profile.repo.*;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Seeds the database with demo data at application startup.
 */
@Configuration
public class DataInitializer {
    @Bean
    ApplicationRunner initData(UserProfileRepository userProfileRepository,
                               ProjectRepository projectRepository,
                               ExperienceRepository experienceRepository,
                               ContributionRepository contributionRepository,
                               MessageRepository messageRepository) {
        return args -> {
            if (userProfileRepository.count() == 0) {
                UserProfile profile = new UserProfile();
                profile.setName("John Doe");
                profile.setTitle("Full Stack Developer");
                profile.setBio("Passionate developer with a love for open source.");
                profile.setAvatarUrl("https://via.placeholder.com/150");
                profile.setLocation("Fairfax, VA");
                profile.setSocials(Arrays.asList("https://github.com/johndoe", "https://linkedin.com/in/johndoe"));
                userProfileRepository.save(profile);
            }

            if (projectRepository.count() == 0) {
                Project p1 = new Project();
                p1.setName("Personal Portfolio");
                p1.setSlug("personal-portfolio");
                p1.setDescription("A personal site to showcase my projects.");
                p1.setUrl("https://example.com");
                p1.setRepo("https://github.com/johndoe/portfolio");
                p1.setTags(Arrays.asList("react", "tailwind"));
                p1.setFeatured(true);
                Project p2 = new Project();
                p2.setName("API Server");
                p2.setSlug("api-server");
                p2.setDescription("A RESTful API built with Spring Boot.");
                p2.setUrl("https://api.example.com");
                p2.setRepo("https://github.com/johndoe/api-server");
                p2.setTags(Arrays.asList("spring", "java"));
                p2.setFeatured(false);
                projectRepository.saveAll(Arrays.asList(p1, p2));
            }

            if (experienceRepository.count() == 0) {
                Experience e1 = new Experience();
                e1.setOrgName("Tech Corp");
                e1.setRole("Software Engineer");
                e1.setStartDate(LocalDate.of(2022, 1, 1));
                e1.setEndDate(null);
                e1.setSummary("Working on full stack applications.");
                e1.setBullets(Arrays.asList("Developed microservices", "Led front‑end team"));
                Experience e2 = new Experience();
                e2.setOrgName("Uni University");
                e2.setRole("B.Sc. Computer Science");
                e2.setStartDate(LocalDate.of(2018, 9, 1));
                e2.setEndDate(LocalDate.of(2022, 5, 31));
                e2.setSummary("Studied algorithms, data structures and software engineering.");
                e2.setBullets(Arrays.asList("Dean's list", "Capstone project on AI"));
                experienceRepository.saveAll(Arrays.asList(e1, e2));
            }

            if (contributionRepository.count() == 0) {
                int currentYear = LocalDate.now().getYear();
                LocalDate start = LocalDate.of(currentYear, 1, 1);
                Random random = new Random();
                for (int i = 0; i < 365; i++) {
                    Contribution c = new Contribution();
                    c.setDate(start.plusDays(i));
                    c.setCount(random.nextInt(5));
                    contributionRepository.save(c);
                }
            }

            // no initial messages seeded
        };
    }
}