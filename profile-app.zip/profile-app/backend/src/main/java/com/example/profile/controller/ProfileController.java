package com.example.profile.controller;

import com.example.profile.model.*;
import com.example.profile.repo.*;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.Year;
import java.util.List;

/**
 * A single REST controller exposing endpoints for the profile app.
 */
@RestController
@RequestMapping
public class ProfileController {

    private final UserProfileRepository userProfileRepository;
    private final ProjectRepository projectRepository;
    private final ExperienceRepository experienceRepository;
    private final ContributionRepository contributionRepository;
    private final MessageRepository messageRepository;

    public ProfileController(UserProfileRepository userProfileRepository,
                             ProjectRepository projectRepository,
                             ExperienceRepository experienceRepository,
                             ContributionRepository contributionRepository,
                             MessageRepository messageRepository) {
        this.userProfileRepository = userProfileRepository;
        this.projectRepository = projectRepository;
        this.experienceRepository = experienceRepository;
        this.contributionRepository = contributionRepository;
        this.messageRepository = messageRepository;
    }

    /**
     * Return the primary user profile.  If none exists this returns HTTP 404.
     */
    @GetMapping("/profile")
    public ResponseEntity<UserProfile> getProfile() {
        return userProfileRepository.findAll().stream().findFirst()
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Return the list of portfolio projects.
     */
    @GetMapping("/projects")
    public List<Project> getProjects() {
        return projectRepository.findAll();
    }

    /**
     * Return the timeline of experiences.
     */
    @GetMapping("/timeline")
    public List<Experience> getTimeline() {
        return experienceRepository.findAll();
    }

    /**
     * Return contribution data for a specific year.
     * @param year the year for which to fetch contributions
     */
    @GetMapping("/stats/contributions")
    public List<Contribution> getContributions(@RequestParam int year) {
        LocalDate start = Year.of(year).atDay(1);
        LocalDate end = Year.of(year).atMonth(12).atEndOfMonth();
        return contributionRepository.findAllByDateBetween(start, end);
    }

    /**
     * Create a new message from the contact form.
     */
    @PostMapping("/contact")
    public ResponseEntity<Message> sendMessage(@Valid @RequestBody Message message) {
        message.setId(null);
        message.setHandled(false);
        message.setCreatedAt(java.time.LocalDateTime.now());
        Message saved = messageRepository.save(message);
        return ResponseEntity.status(201).body(saved);
    }
}